﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OCCDist
{
    public class retDettaglio
    {
        public string Descrizione { get; set; }
        public string Codice_raggruppamento { get; set; }
        public string Descrizione_Spiridon { get; set; }
        public string Catalogo { get; set; }
        public string Descrizione_Prodotto { get; set; }
        public string Fam_SC { get; set; }
        public string Fam_SC_Riv { get; set; }
        public int Sconto { get; set; }
        public int Extra { get; set; }
        public int Ricarica { get; set; }
        public int A_Posizione { get; set; }
        public int B_Posizione { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Configuration;

namespace OCCDist
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        void Session_Start(object sender, EventArgs e)
        {
            string SIEMENS_GID = "";
            string Ambiente = ConfigurationManager.AppSettings["Ambiente"];
            if (Ambiente != "Prod")
                SIEMENS_GID = "Z001SV0T"; // Gianemilio
            else
                SIEMENS_GID = Request.ServerVariables["HTTP_SCGID"];

            Session.Add("SIEMENS_GID", SIEMENS_GID);
            Session.Add("AMMINISTRATORE", false);
            Session.Add("SEGRETERIA", false);
            Session.Add("RESPONSABILE", false);
            Session.Add("UTENTE", false);
            Session.Add("NOMINATIVO", "");

            //Schede
            Session.Add("strSortExpression", "");
            Session.Add("idScheda", "");
            Session.Add("MA", "");
            Session.Add("stato", "");
            Session.Add("rinnovo", "");
            Session.Add("U1Nominativo", "");
            Session.Add("U2Nominativo", "");
            Session.Add("URNominativo", "");
            Session.Add("RivRagioneSociale", "");
            Session.Add("CliRagioneSociale", "");
            Session.Add("Validita_Da", "");
            Session.Add("Validita_A", "");

            SIEMENS_GID = (string)Session["SIEMENS_GID"];
            using (OCCEntities context = new OCCEntities())
            {
                var qryTipoUtente = context.TipoUtente(SIEMENS_GID);
                foreach (var item in qryTipoUtente)
                {
                    switch (item)
                    {
                        case "Amministratore":
                            Session["AMMINISTRATORE"] = true;
                            break;
                        case "Segreteria":
                            Session["SEGRETERIA"] = true;
                            break;
                        case "Responsabile":
                            Session["RESPONSABILE"] = true;
                            break;
                        case "Utente":
                            Session["UTENTE"] = true;
                            var qryUtenti = (from U in context.Utenti
                                             where U.GID == SIEMENS_GID
                                             select U).FirstOrDefault();
                            Session.Add("NOMINATIVO", qryUtenti.Cognome + " " + qryUtenti.Nome);
                            break;
                    }
                }
            }
            Session.Add("idUltimaSchedaInserita", "");
        }
    }
}
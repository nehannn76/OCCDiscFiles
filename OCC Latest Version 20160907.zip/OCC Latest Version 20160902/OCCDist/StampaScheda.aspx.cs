﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OCCDist
{
    public partial class StampaScheda : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if ((Boolean)Session["UTENTE"] == false)
            //{
            //    Response.Redirect("AccessDenied.aspx");
            //}
            BindData();
        }
        private void BindData()
        {
            using (OCCEntities context = new OCCEntities())
            {
                long idIntestazione = Convert.ToInt32(Request.QueryString["idscheda"]);

                var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == idIntestazione);

                if (intestazione.stato == "A")
                    lblApprovata.Text = "Approvata";
                else
                    lblApprovata.Text = "Non Approvata";
                
                var agente1 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente1_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();

                lblAgente1.Text = agente1.Cognome + " " + agente1.Nome;

                var agente2 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente2_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();


                if (agente2 != null)
                {
                    lblAgente2.Text = agente2.Cognome + " " + agente2.Nome;
                }

                var responsabile = (from R in context.Responsabili
                                    join U in context.Utenti on R.GID equals U.GID
                                    where R.Codice_MacroArea == intestazione.Codice_MacroArea && R.GID == intestazione.Responsabile_Gid
                                    select new { R.Codice_MacroArea, R.GID, U.Cognome, U.Nome }).FirstOrDefault();

                lblResponsabile.Text = responsabile.Cognome + " " + responsabile.Nome;
                lblValidita_Da.Text = intestazione.Validita_Da_Mese;
                lblValidita_A.Text = intestazione.Validita_A_Mese;

                var cliente = context.Clienti.FirstOrDefault(C => C.id == intestazione.Cliente);

                lblRagioneSociale.Text = cliente.Ragione_Sociale;
                lblP_Iva.Text = cliente.P_Iva;
                lblComune.Text = cliente.Comune;
                lblCAP.Text = cliente.CAP;
                lblProvincia.Text = cliente.Provincia;

                //var rivenditore = context.Rivenditori.FirstOrDefault(R => R.Codice_MacroArea == intestazione.Codice_MacroArea && R.KN == intestazione.Rivenditore_KN);
                var rivenditore = (from RM in context.RivenditoriMacroarea
                                   join R in context.Rivenditori on RM.KN equals R.KN
                                   where RM.Codice_MacroArea == intestazione.Codice_MacroArea && RM.KN == intestazione.Rivenditore_KN
                                   select new { R.Ragione_Sociale, R.flg_Ricarica }).First();

                lblRivenditore.Text = rivenditore.Ragione_Sociale;
                lblRivenditoreTop.Text = rivenditore.Ragione_Sociale;

                lblFiliale.Text = intestazione.Filiale;

                lblCodice_Cliente.Text = intestazione.Codice_Cliente;
                lblRappresentante_Riv.Text = intestazione.Rappresentante_Riv;
                lblResponsabile_Fil_Riv.Text = intestazione.Responsabile_Fil_Riv != null ? intestazione.Responsabile_Fil_Riv : "n.i.";
                lblFirma_Resp_Fil_Riv.Text = intestazione.Firma_Resp_Fil_Riv != null ? intestazione.Firma_Resp_Fil_Riv : "n.i.";

                // La seguent1 due righe erano precedentemente definite staticamente all'interno dell'aspx
                // siccome l'ultima cella deve comparire se il rivenditore ha la ricarica 
                // dobbiamo costruirle dinamicamente
                TableRow tRowHeader1 = new TableRow();
                tblStampa.Rows.Add(tRowHeader1);
                tRowHeader1.Font.Name = "Arial";
                tRowHeader1.Font.Size = 11;
                tRowHeader1.Font.Bold = true;
                tRowHeader1.HorizontalAlign = HorizontalAlign.Left;
                tRowHeader1.VerticalAlign = VerticalAlign.Top;
                tRowHeader1.BackColor = System.Drawing.Color.Silver;

                TableCell tCell1Header = new TableCell();
                tRowHeader1.Cells.Add(tCell1Header);
                tCell1Header.RowSpan = 2;
                tCell1Header.Controls.Add(new LiteralControl("Descrizione Spiridon"));

                TableCell tCell2Header = new TableCell();
                tRowHeader1.Cells.Add(tCell2Header);
                tCell2Header.RowSpan = 2;
                tCell2Header.Controls.Add(new LiteralControl("Catalogo"));

                TableCell tCell3Header = new TableCell();
                tRowHeader1.Cells.Add(tCell3Header);
                tCell3Header.RowSpan = 2;
                tCell3Header.Controls.Add(new LiteralControl("Descrizione Prodotto"));

                TableCell tCell4Header = new TableCell();
                tRowHeader1.Cells.Add(tCell4Header);
                tCell4Header.ColumnSpan = 2;
                tCell4Header.HorizontalAlign = HorizontalAlign.Center;
                tCell4Header.VerticalAlign = VerticalAlign.Middle;
                tCell4Header.Controls.Add(new LiteralControl("Fam SC"));

                TableCell tCell5Header = new TableCell();
                tRowHeader1.Cells.Add(tCell5Header);
                tCell5Header.RowSpan = 2;
                tCell5Header.HorizontalAlign = HorizontalAlign.Center;
                tCell5Header.VerticalAlign = VerticalAlign.Middle;
                tCell5Header.Controls.Add(new LiteralControl("Sconto"));

                TableCell tCell6Header = new TableCell();
                tRowHeader1.Cells.Add(tCell6Header);
                tCell6Header.RowSpan = 2;
                tCell6Header.HorizontalAlign = HorizontalAlign.Center;
                tCell6Header.VerticalAlign = VerticalAlign.Middle;
                tCell6Header.Controls.Add(new LiteralControl("Extra"));


                if (rivenditore.flg_Ricarica)
                {
                    TableCell tCell7Header = new TableCell();
                    tRowHeader1.Cells.Add(tCell7Header);
                    tCell7Header.RowSpan = 2;
                    tCell7Header.HorizontalAlign = HorizontalAlign.Center;
                    tCell7Header.VerticalAlign = VerticalAlign.Middle;
                    tCell7Header.Controls.Add(new LiteralControl("Sconto Finale"));

                    TableCell tCell8Header = new TableCell();
                    tRowHeader1.Cells.Add(tCell8Header);
                    tCell8Header.RowSpan = 2;
                    tCell8Header.HorizontalAlign = HorizontalAlign.Center;
                    tCell8Header.VerticalAlign = VerticalAlign.Middle;
                    tCell8Header.Controls.Add(new LiteralControl("Ricarica"));
                }
                else
                {
                    TableCell tCell7Header = new TableCell();
                    tRowHeader1.Cells.Add(tCell7Header);
                    tCell7Header.RowSpan = 2;
                    tCell7Header.ColumnSpan = 2;
                    tCell7Header.HorizontalAlign = HorizontalAlign.Center;
                    tCell7Header.VerticalAlign = VerticalAlign.Middle;
                    tCell7Header.Controls.Add(new LiteralControl("Sconto Finale"));
                }

                TableRow tRowHeader2 = new TableRow();
                tblStampa.Rows.Add(tRowHeader2);
                tRowHeader1.Font.Name = "Arial";
                tRowHeader2.Font.Size = 11;
                tRowHeader2.Font.Bold = true;
                tRowHeader2.HorizontalAlign = HorizontalAlign.Center;
                tRowHeader2.VerticalAlign = VerticalAlign.Middle;
                tRowHeader2.BackColor = System.Drawing.Color.LightGray;

                TableCell tCell21Header = new TableCell();
                tRowHeader2.Cells.Add(tCell21Header);
                tCell21Header.BackColor = System.Drawing.Color.FromArgb(51, 204, 204);
                tCell21Header.Controls.Add(new LiteralControl("SIEM"));

                TableCell tCell22Header = new TableCell();
                tRowHeader2.Cells.Add(tCell22Header);
                tCell22Header.BackColor = System.Drawing.Color.Gold;
                tCell22Header.Controls.Add(new LiteralControl(""));


                var query = context.SelCaricaDettaglioDaScheda(idIntestazione).ToList();

                string tmpRaggruppamento = "";
                foreach (var item in query)
                {
                    //DataRow dr = DTDettaglio.NewRow();
                    if (item.SCONTO != 0)
                    {
                        if (tmpRaggruppamento != item.CODICE_RAGGRUPPAMENTO)
                        {

                            TableRow tRowRag = new TableRow();
                            tblStampa.Rows.Add(tRowRag);

                            tRowRag.BackColor = System.Drawing.Color.Gray;
                            tRowRag.Font.Bold = true;

                            //Descrizione_Spiridon
                            TableCell tCell1Rag = new TableCell();
                            tRowRag.Cells.Add(tCell1Rag);
                            tCell1Rag.Font.Name = "Arial";
                            tCell1Rag.Font.Size = 11;
                            tCell1Rag.BackColor = System.Drawing.Color.Gray;
                            tCell1Rag.ForeColor = System.Drawing.Color.White;
                            tCell1Rag.HorizontalAlign = HorizontalAlign.Left;
                            tCell1Rag.Controls.Add(new LiteralControl(item.DESCRIZIONE));

                            //Catalogo
                            TableCell tCell2Rag = new TableCell();
                            tRowRag.Cells.Add(tCell2Rag);
                            tCell2Rag.Font.Name = "Arial";
                            tCell2Rag.Font.Size = 11;
                            tCell2Rag.BackColor = System.Drawing.Color.Gray;
                            tCell2Rag.ForeColor = System.Drawing.Color.White;
                            tCell2Rag.HorizontalAlign = HorizontalAlign.Left;
                            tCell2Rag.Controls.Add(new LiteralControl(""));

                            //Descrizione_Prodotto
                            TableCell tCell3Rag = new TableCell();
                            tRowRag.Cells.Add(tCell3Rag);
                            tCell3Rag.Font.Name = "Arial";
                            tCell3Rag.Font.Size = 11;
                            tCell3Rag.BackColor = System.Drawing.Color.Gray;
                            tCell3Rag.ForeColor = System.Drawing.Color.White;
                            tCell3Rag.HorizontalAlign = HorizontalAlign.Right;
                            tCell3Rag.Controls.Add(new LiteralControl("raggruppamento"));

                            //Codice_raggruppamento
                            TableCell tCell4Rag = new TableCell();
                            tRowRag.Cells.Add(tCell4Rag);
                            tCell4Rag.Font.Name = "Arial";
                            tCell4Rag.Font.Size = 11;
                            tCell4Rag.BackColor = System.Drawing.Color.Gray;
                            tCell4Rag.ForeColor = System.Drawing.Color.White;
                            tCell4Rag.HorizontalAlign = HorizontalAlign.Center;
                            tCell4Rag.Controls.Add(new LiteralControl(item.CODICE_RAGGRUPPAMENTO));

                            //Fam_SC_Riv
                            TableCell tCell5Rag = new TableCell();
                            tRowRag.Cells.Add(tCell5Rag);
                            tCell5Rag.Font.Name = "Arial";
                            tCell5Rag.Font.Size = 11;
                            tCell5Rag.BackColor = System.Drawing.Color.Gray;
                            tCell5Rag.ForeColor = System.Drawing.Color.White;
                            tCell5Rag.HorizontalAlign = HorizontalAlign.Right;
                            tCell5Rag.Controls.Add(new LiteralControl(""));

                            tmpRaggruppamento = item.CODICE_RAGGRUPPAMENTO;
                        }

                        TableRow tRow = new TableRow();
                        tblStampa.Rows.Add(tRow);
                        //Descrizione_Spiridon
                        TableCell tCell1 = new TableCell();
                        tRow.Cells.Add(tCell1);
                        tCell1.Font.Name = "Arial";
                        tCell1.Font.Size = 10;
                        tCell1.HorizontalAlign = HorizontalAlign.Left;
                        tCell1.Controls.Add(new LiteralControl(item.DESCRIZIONE_SPIRIDON));

                        //Catalogo
                        TableCell tCell2 = new TableCell();
                        tRow.Cells.Add(tCell2);
                        tCell2.Font.Name = "Arial";
                        tCell2.Font.Size = 10;
                        tCell2.Font.Italic = true;
                        tCell2.HorizontalAlign = HorizontalAlign.Left;
                        tCell2.Controls.Add(new LiteralControl(item.CATALOGO));

                        //Descrizione_Prodotto
                        TableCell tCell3 = new TableCell();
                        tRow.Cells.Add(tCell3);
                        tCell3.Font.Name = "Arial";
                        tCell3.Font.Size = 10;
                        tCell3.HorizontalAlign = HorizontalAlign.Left;
                        tCell3.Controls.Add(new LiteralControl(item.DESCRIZIONE_PRODOTTO));

                        //Codice_raggruppamento
                        TableCell tCell4 = new TableCell();
                        tRow.Cells.Add(tCell4);
                        tCell4.BackColor = System.Drawing.Color.FromArgb(51, 204, 204);
                        tCell4.Font.Name = "Arial";
                        tCell4.Font.Size = 10;
                        tCell4.HorizontalAlign = HorizontalAlign.Center;
                        tCell4.Controls.Add(new LiteralControl(item.FAM_SC));

                        //Fam_SC_Riv
                        TableCell tCell5 = new TableCell();
                        tRow.Cells.Add(tCell5);
                        tCell5.BackColor = System.Drawing.Color.Gold;
                        tCell5.Font.Name = "Arial";
                        tCell5.Font.Size = 10;
                        tCell5.HorizontalAlign = HorizontalAlign.Center;
                        tCell5.Controls.Add(new LiteralControl(item.FAM_SC_RIV));

                        //Sconto
                        TableCell tCell6 = new TableCell();
                        tRow.Cells.Add(tCell6);
                        tCell6.BackColor = System.Drawing.Color.LightGray;
                        tCell6.Font.Name = "Arial";
                        tCell6.Font.Size = 8;
                        tCell6.HorizontalAlign = HorizontalAlign.Center;
                        tCell6.Controls.Add(new LiteralControl(item.SCONTO.ToString()));

                        //Extra
                        TableCell tCell7 = new TableCell();
                        tRow.Cells.Add(tCell7);
                        tCell7.BackColor = System.Drawing.Color.LightGray;
                        tCell7.Font.Name = "Arial";
                        tCell7.Font.Size = 8;
                        tCell7.HorizontalAlign = HorizontalAlign.Center;
                        tCell7.Controls.Add(new LiteralControl(item.EXTRA.ToString()));

                        if (rivenditore.flg_Ricarica)
                        {
                            //Sconto Finale
                            TableCell tCell8 = new TableCell();
                            tRow.Cells.Add(tCell8);
                            tCell8.Font.Name = "Arial";
                            tCell8.Font.Size = 8;
                            tCell8.HorizontalAlign = HorizontalAlign.Center;
                            decimal iScontoFinale;
                            iScontoFinale = (Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(item.SCONTO) + ((1 - (Convert.ToDecimal(item.SCONTO) / 100)) * item.EXTRA)), 2));
                            tCell8.Controls.Add(new LiteralControl(iScontoFinale.ToString()));

                            //Ricarica
                            TableCell tCell9 = new TableCell();
                            tRow.Cells.Add(tCell9);
                            tCell9.Font.Name = "Arial";
                            tCell9.Font.Size = 8;
                            tCell9.HorizontalAlign = HorizontalAlign.Center;
                            tCell9.Controls.Add(new LiteralControl(item.RICARICA.ToString()));
                        }
                        else
                        {
                            //Sconto Finale
                            TableCell tCell8 = new TableCell();
                            tRow.Cells.Add(tCell8);
                            tCell8.ColumnSpan = 2;
                            tCell8.Font.Name = "Arial";
                            tCell8.Font.Size = 8;
                            tCell8.HorizontalAlign = HorizontalAlign.Center;
                            decimal iScontoFinale;
                            iScontoFinale = (Decimal.Round(Convert.ToDecimal(Convert.ToDecimal(item.SCONTO) + ((1 - (Convert.ToDecimal(item.SCONTO) / 100)) * item.EXTRA)), 2));
                            tCell8.Controls.Add(new LiteralControl(iScontoFinale.ToString()));

                        }
                    }
                }

                // Prezzi netti
                var qryPrezziNetti = context.Prezzi_Netti
                    .Where(I => I.id_Intestazione == idIntestazione)
                    .OrderBy(I => I.Codice_Materiale).ToList();

                if (qryPrezziNetti.Count > 0)
                {
                    TableRow tRowPNHead = new TableRow();
                    tblStampa.Rows.Add(tRowPNHead);

                    tRowPNHead.BackColor = System.Drawing.Color.Gray;
                    tRowPNHead.Font.Bold = true;

                    //Descrizione_Spiridon
                    TableCell tCell1PNHead = new TableCell();
                    tRowPNHead.Cells.Add(tCell1PNHead);
                    tCell1PNHead.Font.Name = "Arial";
                    tCell1PNHead.Font.Size = 11;
                    tCell1PNHead.BackColor = System.Drawing.Color.Gray;
                    tCell1PNHead.ForeColor = System.Drawing.Color.White;
                    tCell1PNHead.HorizontalAlign = HorizontalAlign.Left;
                    tCell1PNHead.Controls.Add(new LiteralControl("Codice Materiale"));

                    //Catalogo
                    TableCell tCell2PNHead = new TableCell();
                    tRowPNHead.Cells.Add(tCell2PNHead);
                    tCell2PNHead.Font.Name = "Arial";
                    tCell2PNHead.Font.Size = 11;
                    tCell2PNHead.BackColor = System.Drawing.Color.Gray;
                    tCell2PNHead.ForeColor = System.Drawing.Color.White;
                    tCell2PNHead.HorizontalAlign = HorizontalAlign.Left;
                    tCell2PNHead.Controls.Add(new LiteralControl("Prezzo Netto"));

                    //Descrizione_Prodotto
                    TableCell tCell3PNHead = new TableCell();
                    tRowPNHead.Cells.Add(tCell3PNHead);
                    tCell3PNHead.Font.Name = "Arial";
                    tCell3PNHead.Font.Size = 11;
                    tCell3PNHead.BackColor = System.Drawing.Color.Gray;
                    tCell3PNHead.ForeColor = System.Drawing.Color.White;
                    tCell3PNHead.HorizontalAlign = HorizontalAlign.Left;
                    tCell3PNHead.Controls.Add(new LiteralControl("Ricarica"));

                    //Codice_raggruppamento
                    TableCell tCell4PNHead = new TableCell();
                    tRowPNHead.Cells.Add(tCell4PNHead);
                    tCell4PNHead.Font.Name = "Arial";
                    tCell4PNHead.Font.Size = 11;
                    tCell4PNHead.BackColor = System.Drawing.Color.Gray;
                    tCell4PNHead.ForeColor = System.Drawing.Color.White;
                    tCell4PNHead.HorizontalAlign = HorizontalAlign.Center;
                    tCell4PNHead.Controls.Add(new LiteralControl(""));

                    //Fam_SC_Riv
                    TableCell tCell5PNHead = new TableCell();
                    tRowPNHead.Cells.Add(tCell5PNHead);
                    tCell5PNHead.Font.Name = "Arial";
                    tCell5PNHead.Font.Size = 11;
                    tCell5PNHead.BackColor = System.Drawing.Color.Gray;
                    tCell5PNHead.ForeColor = System.Drawing.Color.White;
                    tCell5PNHead.HorizontalAlign = HorizontalAlign.Center;
                    tCell5PNHead.Controls.Add(new LiteralControl(""));
                    foreach (Prezzi_Netti prezzinetti in qryPrezziNetti)
                    {

                        TableRow tRowPNRow = new TableRow();
                        tblStampa.Rows.Add(tRowPNRow);
                        //Descrizione_Spiridon
                        TableCell tCell1PNRow = new TableCell();
                        tRowPNRow.Cells.Add(tCell1PNRow);
                        tCell1PNRow.Font.Name = "Arial";
                        tCell1PNRow.Font.Size = 10;
                        tCell1PNRow.HorizontalAlign = HorizontalAlign.Left;
                        tCell1PNRow.Controls.Add(new LiteralControl(prezzinetti.Codice_Materiale));

                        //Catalogo
                        TableCell tCell2PNRow = new TableCell();
                        tRowPNRow.Cells.Add(tCell2PNRow);
                        tCell2PNRow.Font.Name = "Arial";
                        tCell2PNRow.Font.Size = 10;
                        //tCell2PNRow.Font.Italic = true;
                        tCell2PNRow.HorizontalAlign = HorizontalAlign.Left;
                        tCell2PNRow.Controls.Add(new LiteralControl(prezzinetti.Prezzo_Netto.ToString()));

                        //Descrizione_Prodotto
                        TableCell tCell3PNRow = new TableCell();
                        tRowPNRow.Cells.Add(tCell3PNRow);
                        tCell3PNRow.Font.Name = "Arial";
                        tCell3PNRow.Font.Size = 10;
                        tCell3PNRow.HorizontalAlign = HorizontalAlign.Left;
                        tCell3PNRow.Controls.Add(new LiteralControl(prezzinetti.Ricarica.ToString()));

                    }
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SelectPdf;
using System.Net;
using System.IO;
using System.Configuration;

namespace OCCDist
{
    public partial class ModStampa : System.Web.UI.Page
    {
        private string tmpRaggruppamento = "";
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                idNumScheda.Text = Request.QueryString["idscheda"];
                if (!ut.GidCanReadScheda(SIEMENS_GID, idNumScheda.Text))
                    Response.Redirect("MainSchede.aspx", false);

                //if (Request.QueryString["azione"] == "Stampa")
                //{
                    btnCreaPDF.Visible = true;
                    btnCreaExcel.Visible = true;
                    lblHeaderAzione.Text = "Schede - Stampa";
                    lblAzione.Text = "Scheda n.ro :";
                //}
                BindData();
            }
        }
        void BindData()
        {
            CaricaIntestazione();
            //CercaPrezziNetti();
            CaricaDettaglio();

        }
        void CaricaIntestazione()
        {
            //int idIntestazione = Convert.ToInt32((Session["idScheda"]));
            int idIntestazione = Convert.ToInt32(idNumScheda.Text);
            using (OCCEntities context = new OCCEntities())
            {

                var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == idIntestazione);

                lblMacroArea.Text = intestazione.Codice_MacroArea;

                id_modello.Text = intestazione.id_modello.ToString();

                var modello = (from M in context.Modelli_Intestazione
                               where M.id == intestazione.id_modello
                               select new { M.Descrizione }).FirstOrDefault();

                lbl_Descr_Modello.Text = modello.Descrizione;

                lblMCRivenditore.Text = intestazione.Codice_MacroArea;
                lblGid_Agente_1.Text = intestazione.Agente1_Gid;

                var agente1 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente1_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();

                lblAgente1.Text = agente1.Cognome + " " + agente1.Nome;
                lblGid_Agente_2.Text = intestazione.Agente2_Gid;

                var agente2 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente2_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();


                if (agente2 != null)
                {
                    lblAgente2.Text = agente2.Cognome + " " + agente2.Nome;
                }

                var responsabile = (from R in context.Responsabili
                                    join U in context.Utenti on R.GID equals U.GID
                                    where R.Codice_MacroArea == intestazione.Codice_MacroArea && R.GID == intestazione.Responsabile_Gid
                                    select new { R.Codice_MacroArea, R.GID, U.Cognome, U.Nome }).FirstOrDefault();

                lblResponsabile.Text = responsabile.Cognome + " " + responsabile.Nome;
                lblGid_Responsabile.Text = intestazione.Responsabile_Gid;
                lblValidita_Da.Text = intestazione.Validita_Da_Mese;
                lblValidita_A.Text = intestazione.Validita_A_Mese;

                var cliente = context.Clienti.FirstOrDefault(C => C.id == intestazione.Cliente);

                lblRagioneSociale.Text = cliente.Ragione_Sociale;
                lblP_Iva.Text = cliente.P_Iva;
                lblComune.Text = cliente.Comune;
                lblCAP.Text = cliente.CAP;
                lblProvincia.Text = cliente.Provincia;
                id_Cliente.Text = intestazione.Cliente.ToString();

                //var rivenditore = context.Rivenditori.FirstOrDefault(R => R.Codice_MacroArea == intestazione.Codice_MacroArea && R.KN == intestazione.Rivenditore_KN);
                var rivenditore = (from RM in context.RivenditoriMacroarea
                                   join R in context.Rivenditori on RM.KN equals R.KN
                                   where RM.Codice_MacroArea == intestazione.Codice_MacroArea && RM.KN == intestazione.Rivenditore_KN
                                   select new { R.Ragione_Sociale }).First();

                lblRivenditore.Text = rivenditore.Ragione_Sociale;
                lblKNRivenditore.Text = intestazione.Rivenditore_KN;

                lblFiliale.Text = intestazione.Filiale;

                //chkIA.Checked = intestazione.flag_IA;
                //chkDT.Checked = intestazione.flag_DT;
                lblCodice_Cliente.Text = intestazione.Codice_Cliente;
                lblRappresentante_Riv.Text = intestazione.Rappresentante_Riv;
                lblResponsabile_Fil_Riv.Text = intestazione.Responsabile_Fil_Riv;
                lblFirma_Resp_Fil_Riv.Text = intestazione.Firma_Resp_Fil_Riv;

                var stato = (from S in context.Stati_Schede where S.Codice == intestazione.stato select new { S.Descrizione }).FirstOrDefault();
                lblStato.Text = stato.Descrizione;

                idCreatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Creata_il);
                idModificatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Modificata_il);
                idInviatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Inviata_il);
                idApprovatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Approvata_il);

            }
        }
        protected void btnVisualizzaDettaglio_Click(object sender, EventArgs e)
        {
            if (pnlDettaglio.Visible == false)
            {
                pnlDettaglio.Visible = true;
            }
            else
            {
                pnlDettaglio.Visible = false;
            }
        }

        protected void CaricaDettaglio()
        {
            using (OCCEntities context = new OCCEntities())
            {
                int lidIntestazione = Convert.ToInt32(idNumScheda.Text);

                var qrySelCaricaDettaglioDaScheda = context.SelCaricaDettaglioDaScheda(lidIntestazione).ToList();

                var DTDettaglio = new DataTable();
                DTDettaglio.Columns.AddRange(new DataColumn[]{ 
                new DataColumn("Descrizione_raggruppamento" , typeof(string)),
                new DataColumn("Codice_raggruppamento" , typeof(string)),
                new DataColumn("Descrizione_Spiridon" , typeof(string)),
                new DataColumn("Catalogo" , typeof(string)),
                new DataColumn("Descrizione_Prodotto" , typeof(string)),
                new DataColumn("Fam_SC" , typeof(string)),
                new DataColumn("Fam_SC_Riv" , typeof(string)),
                new DataColumn("Sconto" , typeof(string)),
                new DataColumn("Extra" , typeof(string)),
                new DataColumn("Ricarica" , typeof(string)),
            });

                foreach (var item in qrySelCaricaDettaglioDaScheda)
                {
                    DataRow dr = DTDettaglio.NewRow();
                    if (tmpRaggruppamento != item.CODICE_RAGGRUPPAMENTO)
                    {
                        DataRow drRag = DTDettaglio.NewRow();
                        drRag["Descrizione_raggruppamento"] = "";
                        drRag["Codice_raggruppamento"] = "";
                        drRag["Descrizione_Spiridon"] = item.DESCRIZIONE; //Descrizione Raggruppamento
                        drRag["Catalogo"] = "";
                        drRag["Descrizione_Prodotto"] = "Raggruppamento";
                        drRag["Fam_SC"] = item.CODICE_RAGGRUPPAMENTO;
                        drRag["Fam_SC_Riv"] = "";
                        drRag["Sconto"] = "";
                        drRag["Extra"] = "";
                        drRag["Ricarica"] = "";
                        DTDettaglio.Rows.Add(drRag);
                        tmpRaggruppamento = item.CODICE_RAGGRUPPAMENTO;
                    }
                    dr["Descrizione_raggruppamento"] = item.DESCRIZIONE;
                    dr["Codice_raggruppamento"] = item.CODICE_RAGGRUPPAMENTO;
                    dr["Descrizione_Spiridon"] = item.DESCRIZIONE_SPIRIDON;
                    dr["Catalogo"] = item.CATALOGO;
                    if (item.DESCRIZIONE_PRODOTTO.Length > 50)
                        dr["Descrizione_Prodotto"] = item.DESCRIZIONE_PRODOTTO.Substring(0, 50);
                    else
                        dr["Descrizione_Prodotto"] = item.DESCRIZIONE_PRODOTTO;
                    dr["Fam_SC"] = item.FAM_SC;
                    dr["Fam_SC_Riv"] = item.FAM_SC_RIV;
                    dr["Sconto"] = item.SCONTO;
                    dr["Extra"] = item.EXTRA;
                    dr["Ricarica"] = item.RICARICA;
                    DTDettaglio.Rows.Add(dr);
                }
                ViewState["dtDettaglio"] = DTDettaglio;
                GVDettaglio.DataSource = ViewState["dtDettaglio"] as DataTable;
                GVDettaglio.DataBind();
            }
        }
        protected void ddlMacroArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Azzera tutti valori che dipendono dalla macro area
            // Agente 1
            lblAgente1.Text = "";
            lblGid_Agente_1.Text = "";
            // Agente 2
            lblAgente2.Text = "";
            lblGid_Agente_2.Text = "";
            // Responsabile
            lblResponsabile.Text = "";
            lblGid_Responsabile.Text = "";
            // Rivenditore
            lblRivenditore.Text = "";
            lblMCRivenditore.Text = "";
            lblKNRivenditore.Text = "";
            // Cliente
            id_Cliente.Text = "";
            lblRagioneSociale.Text = "";
            lblP_Iva.Text = "";
            lblComune.Text = "";
            lblCAP.Text = "";
            lblProvincia.Text = "";
        }

        protected void GVDettaglio_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
                if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                {
                    e.Row.Cells[8].Text = ""; // intestazione colonna "Ric."
                }
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                Label lblDescProd = (Label)e.Row.FindControl("lblIDescrizione_Prodotto");
                if (lblDescProd.Text == "Raggruppamento")
                {
                    Label lblIDescrizione_Spiridon = (Label)e.Row.FindControl("lblIDescrizione_Spiridon");
                    lblIDescrizione_Spiridon.BackColor = System.Drawing.Color.LightGray;
                    lblIDescrizione_Spiridon.ForeColor = System.Drawing.Color.Gray;
                    Label lblICatalogo = (Label)e.Row.FindControl("lblICatalogo");
                    lblICatalogo.BackColor = System.Drawing.Color.LightGray;
                    lblICatalogo.ForeColor = System.Drawing.Color.Gray;
                    lblDescProd.BackColor = System.Drawing.Color.LightGray;
                    lblDescProd.ForeColor = System.Drawing.Color.Gray;
                    Label lblFamSC = (Label)e.Row.FindControl("lblIFam_SC");
                    lblFamSC.BackColor = System.Drawing.Color.LightGray;
                    lblFamSC.ForeColor = System.Drawing.Color.Gray;
                    e.Row.Font.Bold = true;
                    e.Row.ForeColor = System.Drawing.Color.LightYellow;
                    e.Row.FindControl("lblIFam_SC_Riv").Visible = false;
                    e.Row.FindControl("txtSconto").Visible = false;
                    e.Row.FindControl("txtExtra").Visible = false;
                    e.Row.FindControl("lblSC_Finale").Visible = false;
                    e.Row.FindControl("txtRicarica").Visible = false;
                }
                else
                {
                    if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                    {
                        e.Row.Cells[8].Text = ""; //  colonna "Ric."
                    }
                    TextBox txtSconto = (TextBox)e.Row.FindControl("txtSconto");
                    TextBox txtExtra = (TextBox)e.Row.FindControl("txtExtra");
                    HiddenField hidSC_Finale = (HiddenField)e.Row.FindControl("hidSC_Finale");
                    Label lblSC_Finale = (Label)e.Row.FindControl("lblSC_Finale");
                    txtExtra.Attributes.Add("onblur", "CalcolaSconto('" + txtSconto.ClientID + "','" + txtExtra.ClientID + "','" + hidSC_Finale.ClientID + "','" + lblSC_Finale.ClientID + "')");
                    if (Convert.ToDecimal(txtSconto.Text) > 0)
                    {
                        //var ScontoFinale = parseInt(txtSconto.value) + ((1 - (parseInt(txtSconto.value) / 100)) * parseInt(txtExtra.value));
                        lblSC_Finale.Text = (Decimal.Round(Convert.ToDecimal(txtSconto.Text) + ((1 - (Convert.ToDecimal(txtSconto.Text) / 100)) * Convert.ToDecimal(txtExtra.Text)), 2)).ToString();
                        hidSC_Finale.Value = lblSC_Finale.Text;
                    }
                }
            }
        }
        protected void btnCreaPDF_Click(object sender, EventArgs e)
        {
            string UrlStampa = "";

            string Ambiente = ConfigurationManager.AppSettings["Ambiente"];
            switch (Ambiente)
            {
                case "Test":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaTest"];
                    break;
                case "Qual":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaQual"];
                    break;
                case "Prod":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaProd"];
                    break;
            }

            string url = UrlStampa + idNumScheda.Text;
            //string url = "/StampaScheda?idscheda=" + idNumScheda.Text;

            HtmlToPdf converter = new HtmlToPdf();

            // set converter options
            converter.Options.PdfPageSize = PdfPageSize.A4;
            converter.Options.PdfPageOrientation = PdfPageOrientation.Portrait;
            converter.Options.MarginLeft = 10;
            converter.Options.MarginRight = 10;
            converter.Options.MarginTop = 20;
            converter.Options.MarginBottom = 20;
            //converter.Options.MinPageLoadTime = 2;
            converter.Options.MaxPageLoadTime = 60;
            //converter.Options.AutoFitWidth = HtmlToPdfPageFitMode.NoAdjustment;

            // create a new pdf document converting an url
            PdfDocument doc = converter.ConvertUrl(url);

            ut.InsLog(SIEMENS_GID, "Stampa PDF", Convert.ToInt32(idNumScheda.Text), "INFO", "");

            // save pdf document
            //doc.Save(Response, false, "Sample.pdf");
            doc.Save(Response, false, lblRagioneSociale.Text + "-" + idNumScheda.Text + "-" + lblValidita_Da.Text + "-" + lblValidita_A.Text + ".pdf");

            // close pdf document
            doc.Close();

        }

        protected void btnCreaExcel_Click(object sender, EventArgs e)
        {
            string UrlStampa = "";

            string Ambiente = ConfigurationManager.AppSettings["Ambiente"];
            switch (Ambiente)
            {
                case "Test":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaTest"];
                    break;
                case "Qual":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaQual"];
                    break;
                case "Prod":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaProd"];
                    break;
            }

            string url = UrlStampa + idNumScheda.Text;
            //string url = "StampaScheda?idscheda=" + idNumScheda.Text;

            ut.InsLog(SIEMENS_GID, "Stampa EXCEL", Convert.ToInt32(idNumScheda.Text), "INFO", "");

            WebClient wc = new WebClient();
    
            Stream resStream = wc.OpenRead(url);
            StreamReader sr = new StreamReader(resStream, System.Text.Encoding.UTF8);
            string ContentHtml = sr.ReadToEnd();

            Response.AppendHeader("content-disposition", "attachment;filename=" + lblRagioneSociale.Text + "-" + idNumScheda.Text + "-" + lblValidita_Da.Text + "-" + lblValidita_A.Text + ".xls");
            Response.ContentType = "application/vnd.ms-excel";
            Response.ContentEncoding = System.Text.Encoding.Default;
            //Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.EnableViewState = false;
            Response.Write(ContentHtml);
            Response.End();

        }
    }
}
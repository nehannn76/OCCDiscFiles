﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class ModUtenti : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                GID.Text = Request.QueryString["GID"];
                using (OCCEntities context = new OCCEntities())
                {
                    var utente = context.Utenti.FirstOrDefault(U => U.GID == GID.Text);
                    Cognome.Text = utente.Cognome;
                    Nome.Text = utente.Nome;
                    Email.Text = utente.email;
                    // il Tipo non è più modificabile da interfaccia
                    //Tipo.Text = utente.Tipo;
                    Note.Text = utente.note;

                    GVAssociaUtente.DataSource = context.spGetMacroAree(SIEMENS_GID).ToList();
                    GVAssociaUtente.DataBind();

                    // Responsabili Rivenditori
                    var qrySelResponsabiliRivenditori = context.SelResponsabiliRivenditori(GID.Text).ToList();
                    idBadgeResponsabiliRivenditori.InnerText = (qrySelResponsabiliRivenditori.Count).ToString();

                    if ((bool)Session["AMMINISTRATORE"] == true) btnResponsabiliRivenditori.Visible = true;
                }
            }
        }
        private void BindGrid()
        {
            using (OCCEntities context = new OCCEntities())
            {
                GVAssociaUtente.DataSource = (from C in context.MacroArea select new { C.Codice }).ToList();
                GVAssociaUtente.DataBind();
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities())
            {
                strControllo = "<font color=red><ul>";
                foreach (GridViewRow GVAssociaUtenteRow in GVAssociaUtente.Rows)
                {
                    string strMacroArea = GVAssociaUtenteRow.Cells[0].Text;

                    var qrySchede = context.Schede_Intestazione.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea
                        && (S.Agente1_Gid == GID.Text || S.Agente2_Gid == GID.Text || S.Responsabile_Gid == GID.Text));
                    if (qrySchede != null) // esiste almeno una scheda per cui GID è agente1, agente2 o responsabile, non si può cancellare
                    {
                        strControllo = strControllo + "<li> Cancellazione bloccata! Esiste almeno una scheda per cui " + GID.Text + " è agente1, agente2 o responsabile </li>";
                        break; // esce dal foreach
                    }
                }
                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (OCCEntities context = new OCCEntities())
            {
                var utente = context.Utenti.First(U => U.GID == GID.Text);
                utente.Cognome = Cognome.Text;
                utente.Nome = Nome.Text;
                utente.email = Email.Text;
                // il Tipo non è più modificabile da interfaccia
                //utente.Tipo = Tipo.Text;
                utente.note = Note.Text;
                context.SaveChanges();
                ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Modificato utente: " + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);

                foreach (GridViewRow GVAssociaUtenteRow in GVAssociaUtente.Rows)
                {
                    string strMacroArea = GVAssociaUtenteRow.Cells[0].Text;

                    CheckBox chkSegreteria = (CheckBox)GVAssociaUtenteRow.FindControl("chkSegreteria");
                    var qrySegreteria = context.Segreterie.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea && S.GID == GID.Text);
                    //if (chkSegreteria.Checked == true && segreteria != null) // Non deve fare nulla
                    //{}
                    //if (chkSegreteria.Checked == false && segreteria == null) // Non deve fare nulla
                    //{}
                    if (chkSegreteria.Checked == true && qrySegreteria == null) // Lo deve inserire
                    {
                        Segreterie segreteria = new Segreterie();
                        segreteria.Codice_MacroArea = strMacroArea;
                        segreteria.GID = GID.Text;
                        context.Segreterie.Add(segreteria);
                        context.SaveChanges();
                        ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserita segreteria: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                    }
                    if (chkSegreteria.Checked == false && qrySegreteria != null) // Lo deve cancellare
                    {
                        context.Segreterie.Remove(qrySegreteria);
                        context.SaveChanges();
                        ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminata segreteria: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                    }

                    CheckBox chkAgente = (CheckBox)GVAssociaUtenteRow.FindControl("chkAgente");
                    var qryAgente = context.Agenti.FirstOrDefault(A => A.Codice_MacroArea == strMacroArea && A.Gid == GID.Text);
                    if (chkAgente.Checked == true && qryAgente == null) // Lo deve inserire
                    {
                        Agenti agente = new Agenti();
                        agente.Codice_MacroArea = strMacroArea;
                        agente.Gid = GID.Text;
                        context.Agenti.Add(agente);
                        context.SaveChanges();
                        ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserito agente: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                    }
                    if (chkAgente.Checked == false && qryAgente != null) // Lo deve cancellare
                    {
                        context.Agenti.Remove(qryAgente);
                        context.SaveChanges();
                        ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminato agente: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                    }

                    CheckBox chkResponsabile = (CheckBox)GVAssociaUtenteRow.FindControl("chkResponsabile");
                    var qryResponsabile = context.Responsabili.FirstOrDefault(R => R.Codice_MacroArea == strMacroArea && R.GID == GID.Text);
                    if (chkResponsabile.Checked == true && qryResponsabile == null) // Lo deve inserire
                    {
                        Responsabili responsabile = new Responsabili();
                        responsabile.Codice_MacroArea = strMacroArea;
                        responsabile.GID = GID.Text;
                        context.Responsabili.Add(responsabile);
                        context.SaveChanges();
                        ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserito responsabile: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                    }
                    if (chkResponsabile.Checked == false && qryResponsabile != null) // Lo deve cancellare
                    {
                        context.Responsabili.Remove(qryResponsabile);
                        context.SaveChanges();
                        ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminato responsabile: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                    }
                }
                Response.Redirect("MainUtenti.aspx", false);
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities())
                {
                    foreach (GridViewRow GVAssociaUtenteRow in GVAssociaUtente.Rows)
                    {
                        string strMacroArea = GVAssociaUtenteRow.Cells[0].Text;

                        //CheckBox chkSegreteria = (CheckBox)GVAssociaUtenteRow.FindControl("chkSegreteria");
                        var qrySegreteria = context.Segreterie.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea && S.GID == GID.Text);
                        if (qrySegreteria != null) // Lo deve cancellare
                        {
                            context.Segreterie.Remove(qrySegreteria);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminata segreteria: " + strMacroArea + "|" + GID.Text + "|" + Cognome.Text + "|" + Nome.Text);
                        }

                        //CheckBox chkAgente = (CheckBox)GVAssociaUtenteRow.FindControl("chkAgente");
                        var qryAgente = context.Agenti.FirstOrDefault(A => A.Codice_MacroArea == strMacroArea && A.Gid == GID.Text);
                        if (qryAgente != null) // Lo deve cancellare
                        {
                            context.Agenti.Remove(qryAgente);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminato agente: " + strMacroArea + "|" + GID.Text + "|" + Cognome.Text + "|" + Nome.Text);
                        }

                        //CheckBox chkResponsabile = (CheckBox)GVAssociaUtenteRow.FindControl("chkResponsabile");
                        var qryResponsabile = context.Responsabili.FirstOrDefault(R => R.Codice_MacroArea == strMacroArea && R.GID == GID.Text);
                        if (qryResponsabile != null) // Lo deve cancellare
                        {
                            context.Responsabili.Remove(qryResponsabile);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminato responsabile: " + strMacroArea + "|" + GID.Text + "|" + Cognome.Text + "|" + Nome.Text);
                        }
                    }
                    
                    var utente = context.Utenti.First(U => U.GID == GID.Text);
                    context.Utenti.Remove(utente);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Eliminato utente: " + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);

                    Response.Redirect("MainUtenti.aspx", false);
                }
            }
        }

        protected void GVAssociaUtente_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string strMacroArea = "";
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                strMacroArea = e.Row.Cells[0].Text;

                using (OCCEntities context = new OCCEntities())
                {
                    CheckBox chkSegreteria = (CheckBox)e.Row.FindControl("chkSegreteria");
                    var segreteria = context.Segreterie.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea && S.GID == GID.Text);
                    if (segreteria != null)
                        chkSegreteria.Checked = true;

                    CheckBox chkAgente = (CheckBox)e.Row.FindControl("chkAgente");
                    var agente = context.Agenti.FirstOrDefault(A => A.Codice_MacroArea == strMacroArea && A.Gid == GID.Text);
                    if (agente != null)
                        chkAgente.Checked = true;

                    CheckBox chkResponsabile = (CheckBox)e.Row.FindControl("chkResponsabile");
                    var responsabile = context.Responsabili.FirstOrDefault(R => R.Codice_MacroArea == strMacroArea && R.GID == GID.Text);
                    if (responsabile != null)
                        chkResponsabile.Checked = true;
                }
            }
        }

        protected void chkAgente_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow row = ((GridViewRow)((CheckBox)sender).NamingContainer);
            CheckBox chkAgente = (CheckBox)GVAssociaUtente.Rows[row.RowIndex].FindControl("chkAgente");
            if (chkAgente.Checked == false) // Precedentemente era true, quindi si vorrebbe cancellare un agente, bisogna controllare se è associato ad una scheda
            {
                string strMacroArea = GVAssociaUtente.Rows[row.RowIndex].Cells[0].Text;
                using (OCCEntities context = new OCCEntities())
                {
                    var qrySchede = context.Schede_Intestazione.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea 
                        && (S.Agente1_Gid == GID.Text || S.Agente2_Gid == GID.Text));
                    if (qrySchede != null) // esiste almeno una scheda per cui GID è agente1 o agente2, non si può cancellare, riposizionamo a true il checkbox
                    {
                        chkAgente.Checked = true;
                        string strControllo = "<font color=red><ul>";
                        strControllo = strControllo + "<li> Cancellazione bloccata! Esiste almeno una scheda per cui " + GID.Text + " è agente1 o agente2 </li>";
                        strControllo = strControllo + "</ul></font>";
                        ErrorMessage.Text = strControllo;
                    }
                }
            }
        }

        protected void chkResponsabile_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow row = ((GridViewRow)((CheckBox)sender).NamingContainer);
            CheckBox chkResponsabile = (CheckBox)GVAssociaUtente.Rows[row.RowIndex].FindControl("chkResponsabile");
            if (chkResponsabile.Checked == false) // Precedentemente era true, quindi si vorrebbe cancellare un responsabile, bisogna controllare se è associato ad una scheda
            {
                string strMacroArea = GVAssociaUtente.Rows[row.RowIndex].Cells[0].Text;
                using (OCCEntities context = new OCCEntities())
                {
                    var qrySchede = context.Schede_Intestazione.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea && S.Responsabile_Gid == GID.Text);
                    if (qrySchede != null) // esiste almeno una scheda per cui GID è responsabile, non si può cancellare, riposizionamo a true il checkbox
                    {
                        chkResponsabile.Checked = true;
                        string strControllo = "<font color=red><ul>";
                        strControllo = strControllo + "<li> Cancellazione bloccata! Esiste almeno una scheda per cui " + GID.Text + " è responsabile </li>";
                        strControllo = strControllo + "</ul></font>";
                        ErrorMessage.Text = strControllo;
                    }
                }
            }
        }

        protected void btnResponsabiliRivenditori_Click(object sender, EventArgs e)
        {
            string strTmp = GID.Text;
            strTmp = strTmp + @"&azione=Modifica";
            Response.Redirect("MainResponsabiliRivenditori.aspx?GID=" + strTmp, false);

        }
    }
}
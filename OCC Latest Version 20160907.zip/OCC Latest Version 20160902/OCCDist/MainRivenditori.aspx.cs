﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainRivenditori : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if ((string)Session["idUltimoRivenditoreInserito"] != "" && Session["idUltimoRivenditoreInserito"] != null)
                    idMessage.Text = "Ultimo rivenditore inserito: " + Convert.ToString(Session["idUltimoRivenditoreInserito"]);
                ViewState["RivRagioneSociale"] = "";
                BindGrid();
            }
        }
        void BindGrid()
        {
            using (OCCEntities context = new OCCEntities())
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                var qryCanCreateNew = context.CanCreateNew(SIEMENS_GID).ToList();
                if (qryCanCreateNew.Count > 0)
                {
                    idHypCreaNuova.Visible = true; // Abilita il link per creare un nuovo rivenditore
                }

                if ((string)ViewState["RivRagioneSociale"] == "")
                {
                    var query = from R in context.Rivenditori
                                orderby R.Ragione_Sociale
                                select R;
                    GVRivenditori.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["RivRagioneSociale"];
                    var query = from R in context.Rivenditori
                                where R.Ragione_Sociale.StartsWith(strFilter)
                                orderby R.Ragione_Sociale
                                select R;

                    GVRivenditori.DataSource = query.ToList();
                }

                GVRivenditori.DataBind();
            }
        }
        protected void GVRivenditori_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTmp = ((LinkButton)GVRivenditori.SelectedRow.FindControl("lblKN")).Text.ToString();
            strTmp = strTmp + @"&azione=Modifica";
            Response.Redirect("ModRivenditori.aspx?KN=" + strTmp, false);
        }
        protected void GVRivenditori_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVRivenditori.PageIndex = e.NewPageIndex;
            BindGrid();
        }
        protected void GVRivenditori_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["RivRagioneSociale"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagioneSociale")).Text.ToString();
            BindGrid();
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["RivRagioneSociale"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagioneSociale")).Text.ToString();
            BindGrid();
        }
        protected void GVRivenditori_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["RivRagioneSociale"] != "")
                {
                    var RivRagioneSociale = (TextBox)GVRivenditori.HeaderRow.FindControl("txtRagioneSociale");
                    if (RivRagioneSociale != null)
                        RivRagioneSociale.Text = ViewState["RivRagioneSociale"].ToString().ToUpper();
                }
            }
        }
    }
}